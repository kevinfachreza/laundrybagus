<footer id="ContactLB" class="container-fluid bold">
	<div class="footer-header">Hubungi Kami</div>
	<div class="footer-list">
		0856 4207 1199<br>
		0852 9088 5711<br>
		mesinlaundrysolo@gmail.com<br>
		Jalan Kapten Mulyadi no 264 Solo
	</div>
</footer>
<div class="col-md-12 footer-second text-center">
	CopyRight - LaundryBagus
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>




<script type="text/javascript">
	$(window).scroll(function() {
		var x = $(window).scrollTop();
		if (x == 0) {
		  $('#navbar').removeClass('navbar-mode-1').addClass('navbar-mode-2');
		} else {
		  $('#navbar').removeClass('navbar-mode-2').addClass('navbar-mode-1');
		}
	});
</script>